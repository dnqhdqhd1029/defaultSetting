import React from "react";

const HeaderP = () => {
  return (
    <div className="headerContainer">
      <header>
        <h1 className="logo">기업분석 리포트</h1>
        <div className="lnb">
          <button className="notice" type="button">
            알림 <i className="new" />
          </button>
          <button className="keep" type="button">
            보관함
          </button>
          <button className="quick" type="button">
            빠른메뉴
          </button>
        </div>
      </header>
    </div>
  );
};

export default HeaderP;
