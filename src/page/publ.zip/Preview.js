import React from 'react';
import '../../assets/style/style.scss'
const Preview = () => {
    return (
        <div className="previewWrap">
            <h4>rlsbtjsdl</h4>
        </div>
    );
};

export default Preview;