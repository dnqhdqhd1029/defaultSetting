import React from "react";
import styled from "styled-components";
import { Link } from "react-router-dom";

const HomeContainer = styled.div`
  height: 100vh;

  ul.list {
    padding: 30px 40px;
    font-size: 18px;

    li {
      padding: 10px 0;
      list-style: disc;

      li {
        font-size: 11px;
        list-style: none;
        color: #999;
      }
    }
  }
`;

const Home = () => {
  return (
    <HomeContainer>
      <h1 className="font-xxl">프로젝트</h1>
      <ul className="list">
        <li>
          <Link to={`/layout`}>레이아웃 가이드</Link>
        </li>

        <li>
          <Link to={`/guide`}>guide</Link>
        </li>
        <li>
          <Link to={`/preview`}>미리보기화면</Link>
        </li>
      </ul>

      <h2>기업분석리포트</h2>
      <ul className="list">
        <li>
          <Link to={`/layout`}>기업분석 리포트 메인화면</Link>
        </li>
        <li>
          <Link to={`/guide`}>기업 검색결과</Link>
        </li>
        <li>
          <Link to={`/guide`}>나의 보관함 팝업</Link>
        </li>
        <li>
          <Link to={`/preview`}>나의 큐레이터</Link>
        </li>

        <li>
          <Link to={`/preview`}>일괄리포트 생성 최종확인 팝업 </Link>
        </li>
        <li>
          silver1029
          <Link to1={`/guide`}>최근리포트 목록</Link>
        </li>
        <li>
          <Link to={`/publ/report`}>리포트 상세화면</Link>
        </li>
        <li>
          <Link to={`/guide`}>LLM 생성화면</Link>
        </li>
      </ul>
    </HomeContainer>
  );
};

export default Home;
