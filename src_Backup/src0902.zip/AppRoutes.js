import React from "react";
import { BrowserRouter, useRoutes } from "react-router-dom";
import Home from "./page/publ/Home";
import Layout from "./page/publ/Layout";
import Preview from "./page/publ/Preview";
import NotFound from "./page/publ/NotFound";
import Guide from "./page/publ/Guide";
import Report from "./page/publ/Report";

//import Guide from '/puble/Guide';
//import NotFound from '/puble/NotFound';

const routes = () => [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/layout",
    element: <Layout />,
    // children: [
    //     {
    //         path: '',
    //         element: <TestApp/>,
    //     },
    //     {
    //         path: 'aa',
    //         element: <TestApp2/>,
    //     },
    // ],
  },
  {
    path: "/publ/report",
    element: <Report />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
  {
    path: "/guide",
    element: <Guide />,
  },
  {
    path: "/preview",
    element: <Preview />,
  },
];

const mapRoutes = (routes) => {
  return routes.map(({ path, element, children }) => {
    return {
      path,
      element,
      children: !!children && mapRoutes(children),
    };
  });
};

const BaseRoute = () => {
  return useRoutes(mapRoutes(routes()));
};

const AppRoutes = () => {
  return (
    <BrowserRouter>
      <BaseRoute />
    </BrowserRouter>
  );
};

export default AppRoutes;
